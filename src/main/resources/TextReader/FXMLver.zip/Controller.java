package TextReader;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import TextReader.data.Chapter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;


import TextReader.data.io.TxtFileInput;
import TextReader.data.Paragraph;

public class Controller {
    @FXML
    private BorderPane reader;
    @FXML
    private ListView<Chapter> paraNumber;
    @FXML
    private TextArea paraText;
    @FXML
    private ButtonBar controls;
    @FXML
    private Button textSizePlus;
    @FXML
    private Button textSizeMins;
    @FXML
    private Button catalog;
    Font font = new Font(14);
    TxtFileInput txtFileInput = new TxtFileInput();
    String name;

    public void initialize() {
        String filePath = "J:/Study/卡徒.txt";
        File file = new File(filePath);
        name = file.getName().substring(0, file.getName().lastIndexOf("."));

        txtFileInput.bookFormat(filePath);

        List<Chapter> chapterList = new ArrayList<>();
        Map<String, String> info = txtFileInput.infoRead(name);
        for (int i = 0; i< Integer.parseInt(info.get("chapters")); i++) {
            chapterList.add(txtFileInput.chapterRead(name, i));
        }

        ObservableList<Chapter> observableChapterList = FXCollections.observableArrayList(chapterList);
        paraNumber.setItems(observableChapterList);
//        paraNumber.getItems().setAll();

        //set it to select one item at a time
        paraNumber.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        //set the text area
        paraText.setWrapText(true);
        paraText.setText("←请选择章节");

        // set text size buttons
        Button sizePlus = textSizePlus;
        Button sizeMins = textSizeMins;
        sizePlus.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                font = new Font(font.getSize()+1);
                paraText.setFont(font);
            }
        });
        sizeMins.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                font = new Font(font.getSize()-1);
                paraText.setFont(font);
            }
        });

        // set catalog
        Button catalogSwitch = catalog;
        catalogSwitch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                reader.getLeft().minWidth(0);
            }
        });
    }

    @FXML
    public void handleClickListView() {
        //this is backed by the selectionModel - get the selected item to retrieve the item from the model
        Chapter chapter = paraNumber.getSelectionModel().getSelectedItem();
        List<Paragraph> paragraphs = txtFileInput.contentRead(name, chapter.getNumber());
        StringBuilder sb = new StringBuilder();
        for (Paragraph paragraph : paragraphs) {
            sb.append(paragraph.getText());
            sb.append("\n");
        }
        paraText.setFont(font);
        paraText.setText(sb.toString());
    }
}